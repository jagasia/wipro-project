package com.wipro.ecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wipro3RestJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(Wipro3RestJwtApplication.class, args);
	}

}

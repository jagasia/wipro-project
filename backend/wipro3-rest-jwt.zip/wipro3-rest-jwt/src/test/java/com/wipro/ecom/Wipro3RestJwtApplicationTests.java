package com.wipro.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wipro3RestJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
